from math import log
from math import e

x = [1, 2, 3, 4, 5, 6]
y = [2.25, 3, 4.5, 6, 8.5, 12]

sumX = sum(x)
sumY = 0
sumX_Iny = 0

for i in range(len(y)) :
    valor_log = log(y[i])
    sumY += valor_log
    m = x[i] * valor_log
    sumX_Iny += m

p1 = sumX/len(x)
p2 = sumY/len(y)
vxx = list(map(lambda x, y: x*y, x,x))
sumXX = sum(vxx)

a1 = ((len(x)*sumX_Iny) - (sumX*sumY)) / ((len(y)*sumXX) - (sumX**2))
a0 = p2 - (a1*p1)
alfa = e**a0

print(f'y = {alfa} * e^{a1}x')