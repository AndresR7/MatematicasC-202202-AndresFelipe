
from multiprocessing.managers import _Namespace

def run()
conjuntoA = set({6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30})
conjuntoB = set({0,2,4,6,12,24,40})
conjuntoC = set({ 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44})
conjuntoD = set({2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37})

rta1 = diferencia,(conjuntoA,conjuntoC),di_simetrica(conjuntoB,interseccion,conjuntoD)
    print(f
' La diferencia simetrica de la diferencia entre el conjuntoA y el conjuntoC y la interseccion entre el conjuntoB y el conjuntoD  es: {rta1}')
    elif pregunta = 2:
rta2 = interseccion(conjuntoB,conjuntoD),dif_simetrica(conjuntoC),diferencia(conjuntoA,union,conjuntoD)
     print(f
'La diferencia de la interseccion entre el conjuntoB y el conjuntoD mas la diferencia simetrica del conjuntoC y la union entre el conjuntoA y conjuntoD es: {rta2}')
    elif pregunta = 3:
rta3= interseccion(conjuntoA,conjuntoB,conjuntoC),union(conjuntoA,diferencia,conjuntoB),union(conjuntoB,diferencia,conjuntoD)
    print(f
'La union de la interseccion entre el conjuntoA,conjuntoB,conjuntoC y la union de la diferencia entre el conjuntoA y conjuntoC,conjuntoB y conjuntoD es: {rta3}')
    else:
        print(f 'Digite una opcion que sea valida')
if __name__ ='_main_':
run()






