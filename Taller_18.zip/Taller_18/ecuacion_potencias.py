
from math import log
from math import e

x = [1, 3, 5, 7, 9, 11, 13, 15]
y = [2.1, 3.2, 3.8, 4, 4.2, 4.4, 4.5, 4.7]

sumX = 0
sumY = 0
sumX_Iny = 0
sumXX = 0

for i in range(len(y)) :
    valor_logy= log(y[i], 10)
    valor_logx = log(x[i], 10)
    sumY += valor_logy
    m = valor_logy * valor_logx
    sumX += valor_logx
    sumX_Iny += m
    sumXX += valor_logx**2

p1 = sumX/len(x)
p2 = sumY/len(y)

a1 = ((len(x)*sumX_Iny) - (sumX*sumY)) / ((len(y)*sumXX) - (sumX**2))
a0 = p2 - (a1*p1)
alfa = 10**a0

print(f'y = {alfa} *x^{a1}')