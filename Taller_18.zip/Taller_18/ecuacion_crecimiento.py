from math import log
from math import e

x = [1, 3, 5, 7, 9, 11, 13, 15]
y = [2.1, 3.2, 3.8, 4, 4.2, 4.4, 4.5, 4.7]

sumX = 0
sumY = 0
sumX_Iny = 0
sumXX = 0

for i in range(len(y)) :
    sumX += 1/x[i]
    sumY += 1/y[i]
    m = 1/x[i] * 1/y[i]
    sumX_Iny += m
    sumXX += (1/x[i])**2

p1 = sumX/len(x)
p2 = sumY/len(y)

a1 = ((len(x)*sumX_Iny) - (sumX*sumY)) / ((len(y)*sumXX) - (sumX**2))
a0 = p2 - (a1*p1)
alfa = 1/a0
beta = a1/a0

print(f'y = {alfa} *x/{beta}+x')