x = [0, 1, 3, 5, 6, 8, 9, 12]
y = [3.5, 2.5, 3, 1.5, 2, 1.3, 1, 0.3]

sumX = sum(x)
sumY = sum(y)

p1 = sumX/len(x)
p2 = sumY/len(y)

vxy = list(map(lambda x, y: x*y, x, y))
sumXY = sum(vxy)
vxx = list(map(lambda x, y: x*y, x, x))
sumXX = sum(vxx)

a1 = ((8 * sumXY)-(sumX * sumY)) / ((8 * sumXX)-(sumX**2))
a0 = p2 - (a1 * p1)

print(f'y = {a0} + {a1}x')